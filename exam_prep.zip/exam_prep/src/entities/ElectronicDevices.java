package entities;

import java.util.Collection;

public interface ElectronicDevices extends Comparable<ElectronicDevices> {
	public abstract String infoDevice();	// abstract modifier not required
}
