package entities;

public class Student {
	
}
